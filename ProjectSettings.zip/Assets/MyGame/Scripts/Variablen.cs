using UnityEngine;

public enum Himmelsrichtungen
{
    Nord,
    Sued,
    West,
    Ost
}


public class Variablen : MonoBehaviour
{
    public Color farbe;
    
    [SerializeField]
    int anzTueren;
    bool fahren;
    
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log(
            Himmelsrichtungen.Nord + " " + Himmelsrichtungen.Sued + " " +
            Himmelsrichtungen.West + " " + Himmelsrichtungen.Ost);

        fahren = false;
        anzTueren = 6;
        farbe = Color.black;
    }

    // Update is called once per frame
    void Update()
    {
        if (farbe == Color.black)
        {
            fahren = true;
        }
        else
        {
            anzTueren = 8;
        }
    }
}
